//Travail pratique de Guillaume Sauv� 1440441 et de C�dric Raymond 0867477

package tp2;

public class tp2 {

	public static void main(String[] args) {
        String phrase1 = "SLALTWZKLZJLYPZLZKLQLHUIHWAPZALJSLTLUAXBHUKUVBZJOHUALYVUZSLALTWZKLZJLYPZLZLANHPYVZZPNUVSLATLYSLTVXBLBYZLYVUAAVBZLUMLALSLZILSSLZHBYVUASHMVSPLLUALALLASLZHTVBYLBEKBZVSLPSHBJVLBYXBHUKUVBZJOHUALYVUZSLALTWZKLZJLYPZLZZPMMSLYHIPLUTPLBESLTLYSLTVXBLBYTHPZPSLZAIPLUJVBYASLALTWZKLZJLYPZLZVBSVUZLUCHKLBEJBLPSSPYLUYLCHUAKLZWLUKHUAZKVYLPSSLJLYPZLZKHTVBYHBEYVILZCLYTLPSSLZAVTIHUAZVBZSHMLBPSSLLUNVBAALZKLZHUNTHPZPSLZAIPLUJVBYASLALTWZKLZJLYPZLZWLUKHUAZKLJVYHPSXBVUJBLPSSLLUYLCHUAXBHUKCVBZZLYLGHBALTWZKLZJLYPZLZZPCVBZHCLGWLBYKLZJOHNYPUZKHTVBYLCPALGSLZILSSLZTVPXBPULJYHPUZWHZSLZWLPULZJYBLSSLZQLULCPCYHPWVPUAZHUZZVBMMYPYBUQVBYXBHUKCVBZLUZLYLGHBALTWZKLZJLYPZLZCVBZHBYLGHBZZPKLZJOHNYPUZKHTVBYQHPTLYHPAVBQVBYZSLALTWZKLZJLYPZLZJLZAKLJLALTWZSHXBLQLNHYKLHBJVLBYBULWSHPLVBCLYALLAKHTLMVYABULLUTLAHUAVMMLYALULWVBYYHQHTHPZJHSTLYTHKVBSLBYQHPTLYHPAVBQVBYZSLALTWZKLZJLYPZLZLASLZVBCLUPYXBLQLNHYKLHBJVLBY";
        String phrase2 = "YRNLUCNXYFUXYWFULUNCIHXYMHUNCIHMOHCYMMOLFYMXLICNMXYMJYOJFYMUONIWBNIHYMFYMJYOJFYMUONIWBNIHYMIHNFYXLICNUNCNLYWIFFYWNCZIOCHXCPCXOYFXYDIOCLJFYCHYGYHNXYFYHMYGVFYXYMXLICNMXYFUJYLMIHHYYNXYMFCVYLNYMZIHXUGYHNUFYMLYWIHHOMJULFUWBULNYXYMHUNCIHMOHCYMFUXYWFULUNCIHOHCPYLMYFFYXYMXLICNMXYFUJYLMIHHYYNFYXLICNCHNYLHUNCIHUFLYFUNCZUORXLICNMXYFUJYLMIHHYFYMUONIWBNIHYMJYOJFYMYNCHXCPCXOMMIHNFCVLYMYNYAUORUNIOMFYMUONLYMYNIHNFYXLICNXYHYZUCLYFIVDYNXUHMFYRYLWCWYXYFYOLMXLICNMXUOWOHYZILGYXYXCMWLCGCHUNCIHZIHXYYYHJULNCWOFCYLMOLFYOLILCACHYIOFYOLCXYHNCNYUONIWBNIHYMFYMJYOJFYMUONIWBNIHYMIHNFYXLICNUFUONIXYNYLGCHUNCIHYHPYLNOXYWYXLICNCFMXYNYLGCHYHNFCVLYGYHNFYOLMNUNONJIFCNCKOYYNUMMOLYHNFCVLYGYHNFYOLXYPYFIJJYGYHNYWIHIGCKOYMIWCUFYNWOFNOLYFFYMJYOJFYMUONIWBNIHYMXUHMFYRYLWCWYXYFYOLXLICNUFUONIXYNYLGCHUNCIHIHNFYXLICNXYNLYUONIHIGYMYNXYMUXGCHCMNLYLYORGYGYMJIOLNIONWYKOCNIOWBYUFYOLMUZZUCLYMCHNYLCYOLYMYNFIWUFYMUCHMCKOYXYXCMJIMYLXYMGISYHMXYZCHUHWYLFYOLMUWNCPCNYMUONIHIGYMFYMJYOJFYMUONIWBNIHYMIHNFYXLICNXYGUCHNYHCLYNXYLYHZILWYLFYOLMCHMNCNONCIHMJIFCNCKOYMDOLCXCKOYMYWIHIGCKOYMMIWCUFYMYNWOFNOLYFFYMXCMNCHWNYMNIONYHWIHMYLPUHNFYXLICNMCNYFYMNFYOLWBICRXYJULNCWCJYLJFYCHYGYHNUFUPCYJIFCNCKOYYWIHIGCKOYMIWCUFYYNWOFNOLYFFYXYFYNUNFYMUONIWBNIHYMIHNXLICNUFUPCYUFCHNYALCNYJBSMCKOYYNGYHNUFYUFUFCVYLNYYNUFUMYWOLCNYXYFUJYLMIHHYFYMJYOJFYMUONIWBNIHYMIHNFYXLICNUNCNLYWIFFYWNCZXYPCPLYXUHMFUFCVYLNYFUJUCRYNFUMYWOLCNYYHNUHNKOYJYOJFYMXCMNCHWNMYNHYZIHNFIVDYNXUOWOHUWNYXYAYHIWCXYIOUONLYUWNYXYPCIFYHWYSWIGJLCMFYNLUHMZYLNZILWYXYHZUHNMUONIWBNIHYMXOHALIOJYUOHUONLYFYMUONIWBNIHYMJYOJFYMYNCHXCPCXOMIHNFYXLICNXYHYJUMMOVCLXUMMCGCFUNCIHZILWYYIOXYXYMNLOWNCIHXYFYOLWOFNOLYFYMYNUNMGYNNYHNYHJFUWYXYMGYWUHCMGYMXYJLYPYHNCIHYNXYLYJULUNCIHYZZCWUWYMPCMUHNNIONUWNYUSUHNJIOLVONIOJIOLYZZYNXYJLCPYLFYMUONIWBNIHYMXYFYOLCHNYALCNYYHNUHNKOYJYOJFYMXCMNCHWNMIOXYFYOLMPUFYOLMWOFNOLYFFYMIOFYOLCXYHNCNYYNBHCKOYNIONUWNYUSUHNJIOLVONIOJIOLYZZYNXYFYMXYJIMMYXYLXYFYOLMNYLLYMNYLLCNICLYMIOLYMMIOLWYMNIONYZILGYXYNLUHMZYLNZILWYXYJIJOFUNCIHUSUHNJIOLVONIOJIOLYZZYNXYPCIFYLIOXYLIXYLFOHKOYFWIHKOYXYFYOLMXLICNMNIONYZILGYXUMMCGCFUNCIHIOXCHNYALUNCIHZILWYYNIONYZILGYXYJLIJUAUHXYXCLCAYYWIHNLYYORXUHMFYVONXYHWIOLUAYLFUXCMWLCGCHUNCIHLUWCUFYIOYNBHCKOYIOXSCHWCNYL";
        String phrase3 = "CVRPYGRBCNPGQCBCNMQQCQQGMLBCJMSGQCKGAFCJCRBYLQACRCKNQNPMTGQMGPCCLTCJMNNCCBSJGLACSJBCJYAFPWQYJGBCJFSKYLGRCQCLRBCHYNMGLBPCBCQCLQLMSTCYSVCRQCRCGLBPCOSCJOSCQSLQBCQYLAGLCQJYNCPQMLLYJGRCQYSEKCLRCBCQKGJJGYPBQBCTGCOSGQYEGRCLRYSRMSPBCLMSQNYPCGJJCQYJYEMSRRCBCYSOSGRGCLRYJGKKCLQGRCBCQKCPQJYRCPPCQCKZJCRMSRCNCRGRCMLBGPYGROSCBCQYSRPCQQNFCPCQTGCLLCLRBCQYNNCJQYJGLRCPLYRGMLYJCBCQKMLBCQCRLSJQMSDDJCFSKYGLLCQRNJSQBYLQJCAMCSPLGQSPJCQNYECQMLTGRCLYTYLRQYLQQCPCLBPCAMKNRCNPGKYRCQOSCLMSQMKKCQ";
        String phrase4 = "MpmbfmfuazpgzqbmdfuqpgzmdfuoxqbgnxuqegdxqeufqIqnpqxAZGXqebmkebxgeduotqepauhqzfbmdfmsqdxqehmoouzeXqOAHMJeqefdqfdaghqqzoazogddqzoqmhqopqebmkecguoazoxgqzfpqemooadpepudqofemhqopqeeaouqfqebtmdymoqgfucgqeoqcguqjqdoqgzqbdqeeuazegbbxqyqzfmudqegdxarrdqpuebazunxqpqhmoouzeoazfdqxmOAHUPPmzexqyqyqfqybexqebmkebxgeduotqebqghqzfeqdqfdaghqdmhqogzmbbdahueuazzqyqzfqjoqeeurqzpaeqeXmbbdaotqmofgqxxqpgyaupmnadprmhadueqoqgjcgubqghqzfbmkqdxqbxgeqfoagfqdmruzmxqyqzfbxgeotqdruzmzouqdqyqzfqfqzfqdyqepqhuqebdqhuqzfYyqMnmpHqdsmdmYmueuxqefuybadfmzfpqzafqdcgqxqemooadpenuxmfqdmgjzqybqotqzfbmegzbmkepqdqoqhaudpqepaeqeagpqoazfdungqdmgOAHMJzafmyyqzfbmdxqbmdfmsqpqepaeqe";
        String[] les_phrases = {phrase1,phrase2,phrase3,phrase4};
        // Le for each est pr�sent pour analyser toutes les phrases en m�me temps et pour pouvoir appeller les fonctions pour chaque phrase.
        for(String element : les_phrases)
        {
            int[]char_count = frequencyAnalyser(element);
            int decalage = offsetAnalyser(char_count);
            Decrypter(element, decalage);
            System.out.println(Decrypter(element, decalage));
        }
    }


    /**
     * cette fonction analyse la fr�quence des lettres dans les phrases donn�es
     * @param phrase ce param�tre prends les �l�ments du tableau les_phrases
     * @return ceci retourne le tableau avec les �l�ments modifi�s
     */
	public static int[] frequencyAnalyser(String phrase) 
	{
        //transformation des charact�res en valeurs ASCII
		int[] char_count = new int[26];
        phrase = phrase.toUpperCase();
        for (int i = 0; i < phrase.length(); i++) 
        {
            char character = phrase.charAt(i);
            char_count[(int) character - 65]++;
        }
        return char_count;
    }

   /**
    * cette fonction analyse le d�calage de la lettre la plus utilis�e dans le tableau par rapport � la lettre E dans la langue Fran�aise
    * @param char_count ce param�tre prends les valeurs modifi�es de la fonction FrequencyAnalyser
    * @return ceci retourne le d�calage de la lettre la plus utilis�e par rapport � la lettre E dans la langue Fran�aise
    */
	public static int offsetAnalyser(int[] char_count) 
	{
        int decalage = 0;
        int MostUsedLetter = char_count[0];
        int IndexE = 4;
        int IndexMostUsedLetter = 0;
        //boucle le tableau pour trouver la variable la plus utilis�
        for (int i = 0; i < char_count.length; i++) {
            if (char_count[i] > MostUsedLetter) {
                MostUsedLetter = char_count[i];
                IndexMostUsedLetter = i;
            }
        }
        decalage = IndexMostUsedLetter - IndexE;
        return decalage;
    }

    /**
     * Cette fonction prend les phrases et le d�calage de la lettre la plus utilis�e par rapport � la lettre E dans la langue Fran�aise
     * et d�crypte le texte pour l'afficher dans la langue Fran�aise
     * @param phrases Ce param�tre prends les phrases dans le tableau
     * @param decalage ce param�tre prends le d�calage de la lettre la plus utilis�e par rapport � la lettre E dans la langue Fran�aise
     * @return ceci retourne et affiche le texte d�crypt� au complet.
     */
	public static String Decrypter(String phrases, int decalage) 
	{
        String result = "";
        //V�rification des lettres majuscules et minuscules et conversion du texte encrypt� � la langue Fran�aise
        for(int i=0; i<phrases.length(); i++) 
        {
        	if(Character.isUpperCase(phrases.charAt(i)))
        	{
        		result += (char)((phrases.charAt(i) - decalage - 65 + 26) %26 +65);
        	}
        	else 
        	{
        		result += (char)((phrases.charAt(i) - decalage - 97 +26) %26 +97);
        	}     
        }
        return result;
    }
    }

